
# -*- coding: utf-8 -*-
"""
Authored by Leon Garza

Original file is located at
    https://colab.research.google.com/drive/1VjzeOv58SFkjrvhHMghdf8BjL80af8gt


# RAG with LLaMa 7B

"""

from torch import cuda
from langchain.embeddings.huggingface import HuggingFaceEmbeddings
import os

# Set the environment variable
os.environ['SECRET_TOKEN'] = 'Here goes your hugginface apu key once you have acces to llama2 models'

embed_model_id = 'sentence-transformers/all-MiniLM-L6-v2'

device = f'cuda:{cuda.current_device()}' if cuda.is_available() else 'cpu'

embed_model = HuggingFaceEmbeddings(
    model_name=embed_model_id,
    model_kwargs={'device': device},
    encode_kwargs={'device': device, 'batch_size': 32}
)

"""## Building the Vector Index

We now need to use the embedding pipeline to build our embeddings and store them in a Chroma vector index. To begin we'll initialize our persistent chroma collection
Code for generating this persistent collection is in another file. 
This consistent collection is going to be stored in your computer once you run it.

"""

import chromadb
chroma_client = chromadb.PersistentClient(path = "GDPR")
# This allows us to create a client that connects to the server
collection = chroma_client.get_collection(name="gdpr_regulations")


#Load llama2
from torch import cuda, bfloat16
import transformers

model_id = 'meta-llama/Llama-2-7b-chat-hf'

device = f'cuda:{cuda.current_device()}' if cuda.is_available() else 'cpu'

# set quantization configuration to load large model with less GPU memory
# this requires the `bitsandbytes` library
bnb_config = transformers.BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type='nf4',
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=bfloat16
)

# begin initializing HF items, need auth token for these
hf_auth = 'Here goes your hugginface apu key once you have acces to llama2 models'
model_config = transformers.AutoConfig.from_pretrained(
    model_id,
    use_auth_token=hf_auth
)

model = transformers.AutoModelForCausalLM.from_pretrained(
    model_id,
    trust_remote_code=True,
    config=model_config,
    quantization_config=bnb_config,
    device_map='auto',
    use_auth_token=hf_auth
)
model.eval()
print(f"Model loaded on {device}")

"""The pipeline requires a tokenizer which handles the translation of human readable plaintext to LLM readable token IDs. The Llama 2 7B models were trained using the Llama 2 7B tokenizer, which we initialize like so:"""

tokenizer = transformers.AutoTokenizer.from_pretrained(
    model_id,
    use_auth_token=hf_auth
)

"""Now we're ready to initialize the HF pipeline. There are a few additional parameters that we must define here. Comments explaining these have been included in the code."""

generate_text = transformers.pipeline(
    model=model, tokenizer=tokenizer,
    return_full_text=True,  # langchain expects the full text
    task='text-generation',
    # we pass model parameters here too
    temperature=0.0,  # 'randomness' of outputs, 0.0 is the min and 1.0 the max
    max_new_tokens=512,  # mex number of tokens to generate in the output
    repetition_penalty=1.1  # without this output begins repeating
)

"""
We have to put our llama2 pipeline in langchain pipeline in order to be used in RetrievalQA
"""

from langchain_community.llms import HuggingFacePipeline

llm = HuggingFacePipeline(pipeline=generate_text)
"""
Now we have to Initialize a RetrievalQA Chain and put our collection in a langchain vectorstore.
"""

from langchain_community.vectorstores import Chroma

vectorstore = Chroma(client=chroma_client,
    collection_name="gdpr_regulations",
    embedding_function=embed_model)

from langchain.chains import RetrievalQA

rag_pipeline = RetrievalQA.from_chain_type(
    llm=llm, chain_type='stuff',
    retriever=vectorstore.as_retriever(search_kwargs={"k": 5}),
    return_source_documents=True)

#Here is where the rag results are generated
print(rag_pipeline("Can you browse TheAtlantic.Com site without  submitting your personally identifiable information?"))
print(rag_pipeline("Does IMDB share data with Affiliated Businesses?"))
print(rag_pipeline("How does NYTimes use collected information to customize user experience?"))
print(rag_pipeline("What information is automatically collected by Vox Media?"))
print(rag_pipeline("How does Walmart Use my Personal Information?"))
print(rag_pipeline("What activity information does Reddit collect?"))
print(rag_pipeline("How does Instagram use your information?"))
print(rag_pipeline("What are the conditions for consent according to GDPR?"))
print(rag_pipeline("What are the rights of the data subject related to rectification according to GDPR?"))
print(rag_pipeline("Does the data subject have the right to lodge a complaint with a supervisory authority according to GDPR?"))

print(rag_pipeline("How does Microsoft uses collected data from Xbox and Xbox live?"))
print(rag_pipeline("Which information does Turner Broadcasting System passively collect when you access one of their products?"))
print(rag_pipeline("Where does Discord process data?"))
print(rag_pipeline("Does Canva share user information with business partners?"))
print(rag_pipeline("Who should carry the processing of personal data relating to criminal convictions and offenses according to the GDPR?"))
print(rag_pipeline("What is the data source for Social Blade?"))
print(rag_pipeline("Which choices does a Samsung user has regarding the use of their information?"))
print(rag_pipeline("How does GDPR ensure the lawful process of data for childs?"))
print(rag_pipeline("What are the responsibilities of the controller when implementing new technologies to process data?"))
print(rag_pipeline("What information does Valve collects when you create an account?"))
print(rag_pipeline("How can users limit the data Discord collects?"))

print(rag_pipeline("What is GDPR stance on right to object"))
print(rag_pipeline("What is personal data, and identifiable person according to GDPR"))
print(rag_pipeline("What is the general principle for transfers in GDPR"))
print(rag_pipeline("What is GDPR stance on the processing of employees personal data in the employment context"))
print(rag_pipeline("According to GDPR, does data subjects have the right to lodge a complaint?"))
print(rag_pipeline("According to GDPR, How can a supervisory authority act in case of a urgent need of action in order to protect rights from data subjects?"))
print(rag_pipeline("How does GDPR ensures the independece of the board?"))
print(rag_pipeline("How does the EU ensures the application of GDPR across each of the members?"))
print(rag_pipeline("How does Comission assess the adequacy of the level of protection according to the GDPR "))
print(rag_pipeline("According to GDPR what is the right to rectification"))
print(rag_pipeline("According to GDPR, What are joint controllers?"))

